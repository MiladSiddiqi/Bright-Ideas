from django.urls import path, include           
urlpatterns = [
    path('', include('bright_app.urls')),	   
]