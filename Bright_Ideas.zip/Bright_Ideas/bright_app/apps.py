from django.apps import AppConfig


class BrightAppConfig(AppConfig):
    name = 'bright_app'
